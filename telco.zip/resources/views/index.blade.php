@extends('template')
@section('content')
@include('partials/_slider')
@include('partials/_about')
@include('partials/_services')
@include('partials/_team')
@include('partials/_realisations')
@include('partials/_map')
@include('partials/_contact')

@stop