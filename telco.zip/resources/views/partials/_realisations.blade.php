      <!-- service section starts here -->

      <section class="realisation text-center" id="realisation">
        <div class="container">
          <div class="row">
            <h2 >Nos réalisations</h2>
            <div class="realiser"> <h4> <strong> Telco </strong> est aussi implantée au togo avec TELCO sarl TOGO et au Nigeria avec TELCO Nigeria Limited. Nous avons donc réalisé des travaux dans ces différnts pays, dans lesquels nous avons eu la satisfaction de nos clients</h4></div>

            <div class="col-md-4 col-sm-6">
            <div class="panel panel-primary">
                             <div class="panel-heading"><h4> <center>TELCO TOGO </center> </h4></div>
                             <div class="panel-body">
                              <h4>Nous avons effectué le lancement du service mon incroyable anniversaire avec Moov Togo et Togocel pour la première fois et celui-ci a été un vrai succès. <br>
                              Cela nous inciter à le lancer dans d'autre pays
                               </h4>

                             </div>
            </div>
            
          </div>

          <div class="col-md-4 col-sm-6">
            <div class="panel panel-primary">
                       <div class="panel-heading"><h4><center>NIGERIA</center> </h4></div>
                          <div class="panel-body" class="person-detail">
                            <h4>
                            Déploiement de la 3G à OGUN State pour Glo Nigeria 
                            Déploiement de la 3G à Volta region pour Glo Ghana 
                        Drive test SSV pour la 3G à volta region pour Glo Ghana
                        Drive test de couverture et de Benchmark pour Etisalat Nigeria pour OYO state 
                             </h4>     
                              
                          </div>
            </div>
            
          </div> 
                     <div class="col-md-4 col-sm-6">
            <div class="panel panel-primary">
                             <div class="panel-heading"><h4><center>COTE D'IVOIRE</center> </h4></div>
                             <div class="panel-body">
                              <h4> 
                                    Contrat de SAV avec Orange et MTN pour le service mon incroyable anniversaire <br> 

                                    Contrat avec l'ARTCI (Autorité de Régulation des Télécommunications de Côte D'Ivoire): Campagne d'audit de la qualité de services des reseaux de téléphonie mobile en CI 
                                    
                              </h4>
                             </div>
            </div>
            
          </div> 

                        <style type="text/css">
                          .panel-heading h4{
                            color: #fff;
                          }
                        </style>

                        
          </div>
        </div>
        </div>
      </section><!-- end of service section -->