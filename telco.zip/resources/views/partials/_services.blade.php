			<!-- service section starts here -->

			<section class="service text-center" id="service">
				<div class="container">
					<div class="row">
						<h2>Nos services</h2>
						<div class="offrir"><h4>Notre mission est de fournir aux opérateurs de téléphonie mobile un service de qualité qui intervient dans le domaine des télécommunications, précisement dans le déploiement, la maintenance, l'ingénierie l'optimisation des réseaux mobiles et le développement d'application web et mobile</h4></div>

						<!-- <div class="col-md-3 col-sm-6">
							<div class="single-service">
								<div class="single-service-img">
									<div class="service-img">
										<img class="img-responsive" src="img/service1.png" alt="">
									</div>
								</div>
								<h3>Consulting</h3>
							</div>
						</div>

						<div class="col-md-3 col-sm-6">
							<div class="single-service">
								<div class="single-service-img">
									<div class="service-img">
										<img class="img-responsive" src="img/service2.png" alt="">
									</div>
								</div>
								<h3>Financial</h3>
							</div>
						</div>

						<div class="col-md-3 col-sm-6">
							<div class="single-service">
								<div class="single-service-img">
									<div class="service-img">
										<img class="img-responsive" src="img/service3.png" alt="">
									</div>
								</div>
								<h3>Tax Help</h3>
							</div>
						</div>

						<div class="col-md-3 col-sm-6">
							<div class="single-service">
								<div class="single-service-img">
									<div class="service-img">
										<img class="img-responsive" src="img/service4.png" alt="">
									</div>
								</div>
								<h3>Money</h3>
							</div>
						</div> -->

						

					<div class="col-md-4 col-sm-6">
						<div class="panel panel-primary">
                             <div class="panel-heading"><h4><center>Technology</center> </h4></div>
                             <div class="panel-body">
                             	<div class="person">
								<img class="img-responsive" src="img/item11.jpg" alt="member-1">
							</div>
                             </div>
						</div>
						
					</div> 

					<div class="col-md-4 col-sm-6">
						<div class="panel panel-primary">
                             <div class="panel-heading"><h4> Outsourcing <center></center> </h4></div>
                             <div class="panel-body">
                             	<div class="person">
								<img class="img-responsive" src="img/anniv333.jpg" alt="member-1">
							</div>
                             </div>
						</div>
						
					</div>
                     <div class="col-md-4 col-sm-6">
						<div class="panel panel-primary">
                             <div class="panel-heading"><h4><center>Consultancy</center> </h4></div>
                             <div class="panel-body">
                             	<div class="person">
								<img class="img-responsive" src="img/anniv22.jpg" alt="member-1">
							</div>
                             </div>
						</div>
						
					</div> 

                        <style type="text/css">
                        	.panel-heading h4{
                        		color: #fff;
                        	}
                        </style>
					</div>
				</div>
			</section><!-- end of service section -->