			<section class="slider" id="home">
				<div class="container-fluid">
					<div class="row">

					    <div id="carouselHacked" class="carousel slide carousel-fade" data-ride="carousel">
							<div class="header-backup"></div>
					        <!-- Wrapper for slides -->
					        <div class="carousel-inner" role="listbox">
					            <div class="item active">
					            	<img src="img/slide-one.jpg" alt="">
					                <div class="carousel-caption">
				               			<h1>Intervension</h1>
				               			<p>consulting service</p>
				               			<!--<button>en savoir plus</button>-->
					                </div>
					            </div>
					            <div class="item">
					            	<img src="img/slide-two.jpg" alt="">
					                <div class="carousel-caption">
				               			<h1>Technologie</h1>
				               			<p>Integrateur de solutions</p>
				               			<!--<button>en savoir plus</button>-->
					                </div>
					            </div>
					            <div class="item">
					            	<img src="img/slide-three.jpg" alt="">
					                <div class="carousel-caption">
				               			<h1>Efficacité</h1>
				               			<p>Une équipe hautementement qualifiée</p>
				               			<!--<button>en savoir plus</button>-->
					                </div>
					            </div>
					            <div class="item">
					            	<img src="img/slide-four.jpg" alt="">
					                <div class="carousel-caption">
				               			<h1>Réseaux-telecom</h1>
				               			<p>Un support garantie</p>
				               			<!--<button>en savoir plus</button>-->
					                </div>
					            </div>
					        </div>
 
                            <i class="fa fa-chevron-circle-left" aria-hidden="true"></i>

					        <!-- Controls -->
<a class="left carousel-control" href="#carouselHacked" role="button" data-slide="prev">
					            <span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
					            <span class="sr-only">Previous</span>
					        </a>
					        <a class="right carousel-control" href="#carouselHacked" role="button" data-slide="next">
					            <span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
					            <span class="sr-only">Next</span>
					        </a>
					    </div>

					</div>
				</div>
			</section><!-- end of slider section -->
