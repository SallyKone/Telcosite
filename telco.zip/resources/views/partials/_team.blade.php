<!-- team section -->

			<section class="team" id="team">
				<div class="container">
					<div class="row">
						<div class="team-heading text-center">
							<h2>Notre Equipe</h2>

							<div class="equipe"><h4>Nous disposons de plusieurs techniciens et de cinq ingénieurs ayant les capacités techniques et professionnelles. Le nombre peut croitre avec des agents temporaires de qualité en fonction des offres a exécuter</h4></div>
						</div>

						<div class="col-md-2 single-member col-sm-4">
							<div class="person">
								<img class="img-responsive" src="img/item1.jpg" alt="member-1">
							</div>

							<div class="person-detail">
								<div class="arrow-bottom"></div>
								<h3>Mr. YOUIN</h3>
								<p>Ivoirien(ingénieur électronicien), 20ans d'experience dont 18 ans dans la téléphonie mobile via IVOIRIS, ORANGE et GLO MOBILE Nigeria
								</p>
							</div>
						
						</div>

						<div class="col-md-2 single-member col-sm-4">

							<div class="person-detail">
								<div class="arrow-top"></div>
								<h3>Mr. KOUENON</h3>
								<p>Ivoirien(ingénieur ESCA) 28 ans d'experience dans la gestion d'entreprise </p>
							</div>
							<div class="person">
								<img class="img-responsive" src="img/item2.jpg" alt="member-2">
							</div>
						</div>
						<div class="col-md-2 single-member col-sm-4">
							<div class="person">
								<img class="img-responsive" src="img/item3.jpg" alt="member-3">
							</div>
							<div class="person-detail">
								<div class="arrow-bottom"></div>
								<h3>Mr. VIDELOUP</h3>
								<p>Français (ingénieur economiste), 20ans d'experience, expert dans la recherche et le developpement de nouveaux marchés.</p>
							</div>
						</div>

						<div class="col-md-2 single-member col-sm-4">
							<div class="person-detail">
								<div class="arrow-top"></div>
								<h3>Mr COULIBALY</h3>
								<p>Responsable service informatique et developpement</p>
							</div>
							<div class="person">
								<img class="img-responsive" src="img/item4.jpg" alt="member-4">
							</div>
						</div>

						<div class="col-md-2 single-member col-sm-4">
							<div class="person">
								<img class="img-responsive" src="img/item5.jpg" alt="member-5">
							</div>

							<div class="person-detail">
								<div class="arrow-bottom"></div>
								<h3>Mr. GMONROU </h3>
								<p>Responsable marketing et publicité et de l'entreprise Lorem Ipsum has been the industry's standard dummy text ever since the 1500stext ever since the 1500s</p>
							</div>
						</div>

						<div class="col-md-2 single-member col-sm-4">

							<div class="person-detail">
								<div class="arrow-top"></div>
								<h3>Mlle. KONE</h3>
								<p>Développeur web et mobile</p>
							</div>
							<div class="person">
								<img class="img-responsive" src="img/item6.jpg" alt="member-5">
							</div>

						</div>
					</div>
				</div>
			</section><!-- end of team section -->