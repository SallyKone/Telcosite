@extends('template')
@section('content')
@include('partials/_map')
@include('partials/_contact')
@stop